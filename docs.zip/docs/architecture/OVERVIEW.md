# Architecture overview

## Product boundary

The first release targets Windows 10/11 x64. Before an official PC release and a validated legal installation and launch path exist, the client uses a synthetic fixture and a separate test application. The repository does not distribute game binaries.

## Initial workspace

- `apps/launcher`: Slint UI and Rust desktop entry point. UI content is mock data while the Phase 0 Windows validation remains open.
- `apps/api`: Axum API foundation with health, request IDs, JSON errors, CORS, rate limiting, tracing, graceful shutdown, PostgreSQL pool, and embedded SQLx migrations. Data-backed modules are not implemented yet.
- `infrastructure/compose/docker-compose.yml`: local persistent PostgreSQL and an isolated ephemeral test database profile.
- Future crates for domain, application services, contracts, downloading, manifests, verification, installation, fixture provider, and local storage are added when their boundaries have real code.
- Future `apps/api`: Axum modular monolith backed by PostgreSQL and SQLx.

## Dependency direction

The UI calls application services through UI models. Application services depend on domain types and ports. Infrastructure implements those ports. Domain code does not depend on Slint, HTTP, SQLx, or the filesystem. Long-running work stays off the UI thread.

## Phase 0 decisions

Slint is the selected UI spike, not yet an accepted production framework. The spike must be evaluated on Windows x64 for visual quality, image loading, DPI scaling, resize/focus behavior, cold start, RAM, idle CPU, and licensing before closing Checkpoint 0. See [ADR-0001](../decisions/ADR-0001-slint.md).

